Provide APIs to multi methods for Gau_external command
